from django.apps import AppConfig


class InvConfig(AppConfig):
    name = 'inv'
