"""app URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include


urlpatterns = [
    path('admin/', admin.site.urls),
    #path(route, view, kwargs=None, name=None)
    #Dentro de Include: le llamo 'Bases'
    #include(module, namespace=None)
    #module – URLconf module (or module name)
    #namespace (str) – Instance namespace for the URL entries being included

    #Incluyo los path de las Apps en el fichero URLS.PY general
    path('', include(('apps.bases.urls','bases'), namespace='bases')),   
    #Le digo que cuando alguien escriba en la url la peticion "inv/"
    # va a resolver en el archivo de ruta de la app INV
    path('inv/', include(('apps.inv.urls','inv'), namespace='inv')),   
]
